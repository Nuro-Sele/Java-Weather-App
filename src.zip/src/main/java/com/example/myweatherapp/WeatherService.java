package com.example.myweatherapp;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherService {
    @GET("weather")
    Call<ResponseBody> getWeather(@Query("q") String city, @Query("appid") String apiKey);

    @GET("weather")
    Call<ResponseBody> getWeatherByCoordinates(
            @Query("lat") double latitude,
            @Query("lon") double longitude,
            @Query("appid") String apiKey
    );
}
