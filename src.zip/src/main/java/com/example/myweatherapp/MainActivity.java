package com.example.myweatherapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private EditText editTextCity;
    private Button buttonGetWeather;
    private TextView textViewWeather;
    private TextView textViewMain;
    private TextView textViewMaxTemp;
    private TextView textViewMinTemp;
    private TextView textViewSensation;
    private TextView textViewPressure;
    private TextView textViewHumidity;
    private TextView textViewCity;
    private ImageView imageViewWeatherIcon;
    private ImageView imageViewPressureIcon;
    private ImageView imageViewHumidityIcon;
    private ImageView imageViewSensationIcon;
    private WeatherService weatherService;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextCity = findViewById(R.id.editTextCity);
        buttonGetWeather = findViewById(R.id.buttonGetWeather);
        textViewWeather = findViewById(R.id.textViewWeather);
        textViewMain = findViewById(R.id.textViewMain);
        textViewMaxTemp = findViewById(R.id.textViewMaxTemp);
        textViewMinTemp = findViewById(R.id.textViewMinTemp);
        textViewSensation = findViewById(R.id.textViewSensation);
        textViewPressure = findViewById(R.id.textViewPressure);
        textViewHumidity = findViewById(R.id.textViewHumidity);
        textViewCity = findViewById(R.id.textViewCity);
        imageViewWeatherIcon = findViewById(R.id.imageViewWeatherIcon);
        imageViewPressureIcon = findViewById(R.id.imageViewPressureIcon);
        imageViewHumidityIcon = findViewById(R.id.imageViewHumidityIcon);
        imageViewSensationIcon = findViewById(R.id.imageViewSensationIcon);


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new MyLocationListener();

        if (checkLocationPermission()) {
            // Permission granted, proceed with getting weather
            getCurrentLocationAndFetchWeather();
        } else {
            // Permission not granted, request it
            requestLocationPermission();
        }

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        weatherService = retrofit.create(WeatherService.class);

        buttonGetWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = editTextCity.getText().toString();
                new WeatherAsyncTask().execute(city);
            }
        });
    }

    private void getCurrentLocationAndFetchWeather() {
        if (locationManager != null && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            }
        } else {
            // GPS provider is not enabled, handle accordingly
            showError("GPS provider is not enabled. Please enable GPS and try again.");
        }
    }

    private void showError(String s) {
    }

    // Add this method to stop location updates when the activity is stopped
    @Override
    protected void onStop() {
        super.onStop();
        locationManager.removeUpdates(locationListener);
    }

    private boolean checkLocationPermission() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with getting weather
                getCurrentLocationAndFetchWeather();
            } else {
                // Permission denied, handle accordingly
                showError("Location permission denied. Weather data based on current location won't be available.");
            }
        }
    }

    private class MyLocationListener implements LocationListener {
        @Override
        public void onLocationChanged(Location location) {
            // Use the location to fetch weather
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            new WeatherAsyncTask().execute(latitude, longitude);
            locationManager.removeUpdates(this); // Stop listening for location updates
        }

        @Override
        public void onProviderDisabled(String provider) {
            // Handle when the location provider is disabled
            showError("Location provider is disabled. Please enable location services and try again.");
        }

        @Override
        public void onProviderEnabled(String provider) {
            // Handle when the location provider is enabled
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            // Handle changes in location provider status
        }

        private void showError(String message) {
            // Update UI to show error message
            textViewWeather.setText(message);
        }
    }


    private class WeatherAsyncTask extends AsyncTask<Object, Void, WeatherData> {
        @Override
        protected WeatherData doInBackground(Object... params) {
            try {
                if (params.length == 2) {
                    // If params contain latitude and longitude
                    double latitude = (double) params[0];
                    double longitude = (double) params[1];
                    String apiKey = "492826dbdf602d2f4dabf284a9480cc1";
                    Call<ResponseBody> call = weatherService.getWeatherByCoordinates(latitude, longitude, apiKey);
                    Response<ResponseBody> response = call.execute();
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        return parseWeatherData(result);
                    }
                } else if (params.length == 1) {
                    // If params contain city name
                    String city = (String) params[0];
                    String apiKey = "492826dbdf602d2f4dabf284a9480cc1";
                    Call<ResponseBody> call = weatherService.getWeather(city, apiKey);
                    Response<ResponseBody> response = call.execute();
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        return parseWeatherData(result);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                // Handle the exception and return an error message
                showError("Error: Unable to fetch weather data.");
            }
            // Return null if there's an issue
            return null;
        }

        @Override
        protected void onPostExecute(WeatherData weatherData) {
            super.onPostExecute(weatherData);

            if (weatherData != null) {
                // Display the weather data
                displayWeatherData(weatherData, imageViewWeatherIcon, textViewMain);
            } else {
                // Handle the case where weatherData is null
                showError("Error: Unable to fetch weather data.");
            }
        }

        private WeatherData parseWeatherData(String result) {
            try {
                Gson gson = new Gson();
                JsonObject json = gson.fromJson(result, JsonObject.class);
                String cityName = json.get("name").getAsString();

                // Retrieve the "weather" array
                JsonArray weatherArray = json.getAsJsonArray("weather");


                if (weatherArray.size() > 0) {

                    JsonObject weatherObject = weatherArray.get(0).getAsJsonObject();

                    // Retrieve the icon code
                    String iconCode = weatherObject.get("icon").getAsString();


                    String iconUrl;
                    switch (iconCode){
                        case "01d":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-1/32/Weather_Icon-04-128.png";
                            break;

                        case "02d":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-1/32/Weather_Icon-28-128.png";
                            break;

                        case "03d":
                            iconUrl = "https://cdn1.iconfinder.com/data/icons/vacation-landmarks/512/53-128.png";
                            break;

                        case "04d":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-1/32/Weather_Icon-17-128.png";
                            break;

                        case "09d":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-10/32/Weather_Icon-18-128.png";
                            break;

                        case "10d":
                            iconUrl = "https://cdn2.iconfinder.com/data/icons/weather-forecast-meteorology-set-7/32/Weather_Icon-04-128.png";
                            break;

                        case "11d":
                            iconUrl = "https://cdn2.iconfinder.com/data/icons/weather-forecast-meteorology-set-5-1/32/Weather_Icon-32-128.png";
                            break;

                        case "13d":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-6-1/32/Weather_Icon-60-128.png";
                            break;

                        case "50d":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-6-1/32/Weather_Icon-54-128.png";
                            break;

                        case "01n":
                            iconUrl = "https://cdn2.iconfinder.com/data/icons/weather-forecast-meteorology-set-5-1/32/Weather_Icon-28-128.png";
                            break;

                        case "02n":
                            iconUrl = "https://cdn0.iconfinder.com/data/icons/weather-forecast-meteorology-set-2/32/Weather_Icon-33-128.png";
                            break;

                        case "03n":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-1/32/Weather_Icon-10-128.png";
                            break;

                        case "04n":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-1/32/Weather_Icon-15-128.png";
                            break;

                        case "09n":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-1/32/Weather_Icon-20-128.png";
                            break;

                        case "10n":
                            iconUrl = "https://cdn0.iconfinder.com/data/icons/weather-forecast-meteorology-set-4-1/32/Weather_Icon-18-128.png";
                            break;

                        case "11n":
                            iconUrl = "https://cdn2.iconfinder.com/data/icons/weather-forecast-meteorology-set-5-1/32/Weather_Icon-30-128.png";
                            break;

                        case "13n":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-6-1/32/Weather_Icon-59-128.png";
                            break;

                        case "50n":
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/weather-forecast-meteorology-set-10/32/Weather_Icon-23-128.png";
                            break;

                        default:
                            iconUrl = "https://cdn3.iconfinder.com/data/icons/spring-2-1/30/Rainbow-512.png        ";
                            break;
                    }

                    JsonObject main = json.getAsJsonObject("main");
                    double temperatureKelvin = main.get("temp").getAsDouble();
                    double minTemperature = main.get("temp_min").getAsDouble();
                    double maxTemperature = main.get("temp_max").getAsDouble();
                    double sensation = main.get("feels_like").getAsDouble();
                    int pressure = main.get("pressure").getAsInt();
                    int humidity = main.get("humidity").getAsInt();

                    int temperatureCelsius = (int) Math.round(temperatureKelvin - 273.15);
                    int thermicSensation = (int) Math.round(sensation - 273.15);
                    int maxTemp = (int) Math.round(maxTemperature - 273.15);
                    int minTemp = (int) Math.round(minTemperature - 273.15);



                    String weatherCondition = weatherObject.get("main").getAsString();


                    return new WeatherData(cityName, temperatureCelsius, iconUrl, weatherCondition, maxTemp, minTemp, thermicSensation, pressure, humidity);
                }
            } catch (JsonParseException e) {
                e.printStackTrace();
                // Handle the exception and show an error message
                showError("Error: Unable to parse weather data.");
            }
            // Return null if there's an issue
            return null;
        }

        private void displayWeatherData(WeatherData weatherData, ImageView imageViewWeatherIcon, TextView textViewMain) {
            // Display the weather data in the UI
            String cityName = weatherData.getCityName();
            int temperatureCelsius = weatherData.getTemperatureCelsius();
            String iconUrl = weatherData.getIconUrl();
            String main = weatherData.getWeatherCondition();

            int Max_temp = weatherData.getMax_temp();
            int Min_temp = weatherData.getMin_temp();

            int Sensation = weatherData.getSensation();
            int pressure = weatherData.getPressure();
            int humidity = weatherData.getHumidity();

            textViewMaxTemp.setText("Max.: " + String.valueOf(Max_temp) + "ºC");
            textViewMinTemp.setText("Min.: " + String.valueOf(Min_temp) + "ºC");
            textViewSensation.setText("Sensation: " + Sensation + "ºC");
            textViewPressure.setText("Pressure: " + pressure + " Pa");
            textViewHumidity.setText("Humidity: " + humidity + "%");


            textViewMain.setText(main);

            // Update UI with weather information
            textViewWeather.setText(temperatureCelsius + " °C");

            textViewCity.setText(cityName);

            // Picasso to load and display the weather icon
            Picasso.get().load(iconUrl).into(imageViewWeatherIcon);
            Picasso.get().load("https://cdn1.iconfinder.com/data/icons/welding-metal-works-blue/64/64_welding-manometer-pressure-256.png").into(imageViewPressureIcon);
            Picasso.get().load("https://cdn0.iconfinder.com/data/icons/30-weather-6/512/28_Humidity-64.png").into(imageViewHumidityIcon);
            Picasso.get().load("https://cdn4.iconfinder.com/data/icons/weather-vol-02-5/32/temperature-thermometer-humidity-rainfall-measurement-precipitation-forecast-256.png").into(imageViewSensationIcon);
        }


        private void showError(String message) {
            // Update UI to show error message
            textViewWeather.setText(message);
        }
    }

    private class WeatherData {
        private String cityName;
        private int temperatureCelsius;
        private int Max_temp;
        private int Min_temp;
        private String iconUrl;
        private String weatherCondition;
        private int Sensation;
        private int pressure;
        private int humidity;

        public WeatherData(String cityName, int temperatureCelsius, String iconUrl, String weatherCondition, int Max_temp, int Min_temp, int Sensation, int pressure, int humidity) {
            this.cityName = cityName;
            this.temperatureCelsius = temperatureCelsius;
            this.iconUrl = iconUrl;
            this.weatherCondition = weatherCondition;
            this.Max_temp = Max_temp;
            this.Min_temp = Min_temp;
            this.Sensation = Sensation;
            this.pressure = pressure;
            this.humidity = humidity;
        }

        public String getCityName() {
            return cityName;
        }

        public int getTemperatureCelsius() {
            return temperatureCelsius;
        }

        public String getIconUrl() {
            return iconUrl;
        }
        public String getWeatherCondition() {
            return weatherCondition;
        }

        public int getMax_temp(){
            return Max_temp;
        }
        public int getMin_temp(){
            return Min_temp;
        }

        public int getSensation(){return Sensation;}
        public int getPressure(){return pressure;}
        public int getHumidity(){return humidity;}
    }
}
